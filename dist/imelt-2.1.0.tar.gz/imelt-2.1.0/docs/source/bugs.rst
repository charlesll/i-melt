Errors and bugs
===============

Please report any issue with the software using the `Github issue system <https://github.com/charlesll/i-melt/issues>`_ or sending an email at lelosq@ipgp.fr